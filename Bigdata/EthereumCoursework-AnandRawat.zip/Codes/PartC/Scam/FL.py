from mrjob.job import MRJob

class T1(MRJob):

  def mapper(self, _,line):
         fields = line.split(",")
         try:

             scam = fields[6]
             scam = scam[14:-1]
             address = fields[0]
             yield(scam, address)

         except:
             pass



if __name__ == '__main__':
    T1.run()
