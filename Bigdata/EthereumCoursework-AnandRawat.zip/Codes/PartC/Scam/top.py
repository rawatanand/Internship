from mrjob.job import MRJob
import re
import time
import statistics
class T3(MRJob):


  def mapper(self, _, line):
      try:
         fields = line.split()
         address = fields[1]
         address = address[3:-4]
         value = int(fields[2])
         yield (address, value)
      except:
         pass


  def reducer(self, word, counts):
       yield (word, sum(counts))



if __name__ == '__main__':
    T3.run()
