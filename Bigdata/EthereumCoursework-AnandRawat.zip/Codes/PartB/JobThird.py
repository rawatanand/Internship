from mrjob.job import MRJob

class JobThird(MRJob):

    def mapper(self, _, line):
        try:
            fields = line.split()
            address = fields[0][2:-2]
            block = fields[1][1:-2]
            address = address + ' - ' + block
            value = int(fields[2])
            yield(None, (address, value))
        except:
            pass

    def reducer(self, _, values):
        values = sorted(values, reverse=True, key=lambda l: l[1])
        values = values[:10]
        for value in values:
            address = value[0]
            val = value[1]
            yield(address, val)

if __name__ == '__main__':
    JobThird.run()
