
from mrjob.job import MRJob

class JobFirst(MRJob):

    def mapper(self, _, line):
        try:
            fields = line.split(',')
            address = fields[2]
            value = int(fields[3])
            if value == 0:
                pass
            else:
                yield(address, value)
        except:
            pass

    def combiner(self, address, value):
        yield(address, sum(value))

    def reducer(self, address, value):
        yield(address, sum(value))

if __name__ == '__main__':
    JobFirst.run()
